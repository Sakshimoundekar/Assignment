package resources;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Webdriver {
       public static WebDriver driver;
       public static WebDriver createDriver() {
           System.setProperty("webdriver.chrome.driver", "C:\\Users\\Lenovo\\Downloads\\chromedriver-win64.exe");
           WebDriver driver = new ChromeDriver();
           driver.manage().window().maximize();
           return driver;
       
       }        
}
